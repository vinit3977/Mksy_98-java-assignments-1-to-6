package com.mycompany.app;
import com.mycompany.math.Calculator;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        int resultAdd = calculator.add(10, 5);
        System.out.println("Addition Result: " + resultAdd);

        int resultSubtract = calculator.subtract(20, 7);
        System.out.println("Subtraction Result: " + resultSubtract);
    }
}
