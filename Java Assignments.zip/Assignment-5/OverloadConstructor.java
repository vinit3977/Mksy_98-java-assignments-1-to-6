class OverloadConstructor {
    private int number;

    public MyClass() {
        this.number = 0;
    }

    public MyClass(int number) {
        this.number = number;
    }

    public MyClass(int number1, int number2) {
        this.number = number1 + number2;
    }

    public void displayNumber() {
        System.out.println("Number: " + this.number);
    }
}

public class Main {
    public static void main(String[] args) {
        MyClass obj1 = new MyClass(); 
        obj1.displayNumber(); 

        MyClass obj2 = new MyClass(42); 
        obj2.displayNumber(); 

        MyClass obj3 = new MyClass(10, 20); 
        obj3.displayNumber(); 
    }
}
