class Animal {
    void eat() {
        System.out.println("Eating...");
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("Barking...");
    }
}

class Labrador extends Dog {
    void color() {
        System.out.println("Labrador is black");
    }
}

public class Main {
    public static void main(String[] args) {
        Labrador lab = new Labrador();
        lab.eat();   // Output: Eating...
        lab.bark();  // Output: Barking...
        lab.color(); // Output: Labrador is black
    }
}
