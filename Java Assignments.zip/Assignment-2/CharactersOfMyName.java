public class CharactersOfMyName {
    public static void main(String[] args) {
        char[] nameChars = {'D', 'I', 'P', 'I', 'K', 'A'};
        String name = new String(nameChars);
        System.out.println(name);
    }
}
