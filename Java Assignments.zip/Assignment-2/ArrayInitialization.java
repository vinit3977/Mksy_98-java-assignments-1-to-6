public class ArrayInitialization {

    public static void main(String[] args) {

        // Method 1: Initialize array with specific values
        int[] arr1 = {1, 2, 3, 4, 5};

        // Method 2: Specify array size and then assign values
        int[] arr2 = new int[5];
        arr2[0] = 1;
        arr2[1] = 2;
        arr2[2] = 3;
        arr2[3] = 4;
        arr2[4] = 5;

        // Method 3: Initialize array using a loop
        int[] arr3 = new int[5];
        for (int i = 0; i < 5; i++) {
            arr3[i] = i + 1;
        }

        // Printing the arrays
        System.out.print("arr1: ");
        for (int num : arr1) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.print("arr2: ");
        for (int num : arr2) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.print("arr3: ");
        for (int num : arr3) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
