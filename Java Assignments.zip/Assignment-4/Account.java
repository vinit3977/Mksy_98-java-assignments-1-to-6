class Account {
    double balance;

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    public double checkBalance() {
        return balance;
    }
}

public class Main {
    public static void main(String[] args) {
        Account account = new Account();
        account.deposit(1000.0);

        double balance = account.checkBalance();
        System.out.println("Current balance: " + balance);

        account.withdraw(500.0);
        balance = account.checkBalance();
        System.out.println("Current balance: " + balance);

        account.withdraw(700.0); // This will print "Insufficient funds."
    }
}
