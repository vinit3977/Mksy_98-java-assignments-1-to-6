class InitializeViaConstructor {
    String name;
    int id;

    public Student(String n, int i) {
        name = n;
        id = i;
    }

    public void displayValues() {
        System.out.println("Name: " + name + ", ID: " + id);
    }
}

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Dipika Suklan", 12345);
        student1.displayValues();

        Student student2 = new Student("Chandni Mehra", 67890);
        student2.displayValues();
    }
}
