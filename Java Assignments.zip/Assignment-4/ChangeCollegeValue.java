class ChangeCollegeVaue {
    String name;
    int id;
    static String college = "ABC University";

    public static void changeCollege(String newCollege) {
        college = newCollege;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Original College: " + Student.college);

        Student.changeCollege("XYZ University");

        System.out.println("Updated College: " + Student.college);
    }
}
