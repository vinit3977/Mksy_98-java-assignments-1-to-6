class HelloWorldUsingStaticBlock {
    static {
        System.out.println("Hello World");
    }
}

public class Main {
    public static void main(String[] args) {
        
    }
}
