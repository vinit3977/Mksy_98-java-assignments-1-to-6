class Shape {
    double area;

    public Shape(double side) {
        area = side * side; // For square
    }

    public Shape(double length, double breadth) {
        area = length * breadth; // For rectangle
    }

    public Shape(double base, double height, boolean isTriangle) {
        area = 0.5 * base * height; // For triangle
    }

    public Shape(double radius, boolean isCircle) {
        area = Math.PI * radius * radius; // For circle
    }

    public double getArea() {
        return area;
    }
}
