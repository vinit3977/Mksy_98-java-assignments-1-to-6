public class SimpleInterestRange {
    public static void main(String[] args) {
        double principal = 1000;
        int years = 5;

        for (int rate = 1; rate <= 10; rate++) {
            double interest = (principal * rate * years) / 100;
            System.out.println("Simple Interest for " + rate + "%: " + interest);
        }
    }
}
