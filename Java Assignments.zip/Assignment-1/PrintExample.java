public class PrintExample {
    public static void main(String[] args) {
        System.out.print("This is ");
        System.out.println("an example");
    }
}
