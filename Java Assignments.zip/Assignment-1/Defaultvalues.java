public class DefaultValues {
    static int intDefault;
    static byte byteDefault;
    static short shortDefault;
    static long longDefault;
    static float floatDefault;
    static double doubleDefault;
    static char charDefault;
    static boolean booleanDefault;

    public static void main(String[] args) {
        System.out.println("Default values:");
        System.out.println("int: " + intDefault);
        System.out.println("byte: " + byteDefault);
        System.out.println("short: " + shortDefault);
        System.out.println("long: " + longDefault);
        System.out.println("float: " + floatDefault);
        System.out.println("double: " + doubleDefault);
        System.out.println("char: " + charDefault);
        System.out.println("boolean: " + booleanDefault);
    }
}
