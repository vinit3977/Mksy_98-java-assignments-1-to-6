public class MaximumOfThree {
    public static void main(String[] args) {
        int a = 5, b = 10, c = 8;
        int max = a;

        if (b > max) {
            max = b;
        }

        if (c > max) {
            max = c;
        }

        System.out.println("Maximum: " + max);
    }
}
