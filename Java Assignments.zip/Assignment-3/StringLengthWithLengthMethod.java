public class StringLengthWithLengthMethod {
    public static void main(String[] args) {
        String name = "HappyGoLucky";
        int length = name.length();
        System.out.println("Length of the string: " + length);
    }
}
