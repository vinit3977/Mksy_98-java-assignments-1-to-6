public class StringLiteral {
    public static void main(String[] args) {
        String name = "Lily Bloom";
        System.out.println(name);
    }
}
