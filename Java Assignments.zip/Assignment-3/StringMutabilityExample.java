public class StringMutabilityExample {
    public static void main(String[] args) {
        
        StringBuffer stringBuffer = new StringBuffer("Hello, ");
        stringBuffer.append("World!");
        String mutableString = stringBuffer.toString();

        System.out.println("Mutable String (created using StringBuffer): " + mutableString);

        String immutableString = "Hello, Java!";
        StringBuffer mutableBuffer = new StringBuffer(immutableString);

        String immutableFromStringBuffer = mutableBuffer.toString();

        System.out.println("Immutable String (converted from StringBuffer): " + immutableFromStringBuffer);
    }
}
