public class StringConversionExample {
    public static void main(String[] args) {
        // Task 1: Create a string using StringBuilder Class
        StringBuilder stringBuilder = new StringBuilder("Hello, World!");

        System.out.println("StringBuilder String: " + stringBuilder);

        // Task 2: Convert the above string to StringBuffer type
        StringBuffer stringBuffer = new StringBuffer(stringBuilder);

        System.out.println("StringBuffer String: " + stringBuffer);

        // Task 3: Convert the above string to immutable type
        String immutableString = stringBuffer.toString();

        System.out.println("Immutable String: " + immutableString);
    }
}
