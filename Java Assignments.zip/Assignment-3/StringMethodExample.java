public class StringMethodsExample {
    public static void main(String[] args) {
        String str = "Hello, World!";
        
        // a) char charAt(int index)
        char charAtIndex = str.charAt(7);
        System.out.println("Character at index 7: " + charAtIndex);

        // b) int length()
        int strLength = str.length();
        System.out.println("Length of the string: " + strLength);

        // c) String substring(int beginIndex)
        String substring = str.substring(7);
        System.out.println("Substring from index 7: " + substring);

        // d) boolean contains(CharSequence s)
        boolean containsHello = str.contains("Hello");
        System.out.println("Contains 'Hello': " + containsHello);

        // e) boolean equals(Object another)
        String anotherString = "Hello, World!";
        boolean isEqual = str.equals(anotherString);
        System.out.println("Strings are equal: " + isEqual);

        // f) boolean isEmpty()
        boolean isEmpty = str.isEmpty();
        System.out.println("Is the string empty: " + isEmpty);

        // g) String concat(String str)
        String concatenatedString = str.concat(" How are you?");
        System.out.println("Concatenated String: " + concatenatedString);

        // h) String replace(char old, char new)
        String replacedString = str.replace('o', '0');
        System.out.println("Replaced String: " + replacedString);

        // i) int indexOf(int ch)
        int indexOfW = str.indexOf('W');
        System.out.println("Index of 'W': " + indexOfW);

        // j) String toLowerCase()
        String lowerCaseString = str.toLowerCase();
        System.out.println("Lowercase string: " + lowerCaseString);

        // k) String toLowerCase(Locale l) - Not demonstrated here

        // l) String toUpperCase()
        String upperCaseString = str.toUpperCase();
        System.out.println("Uppercase string: " + upperCaseString);

        // m) String toUpperCase(Locale l) - Not demonstrated here

        // n) String trim()
        String stringWithSpaces = "   Trim Me!   ";
        String trimmedString = stringWithSpaces.trim();
        System.out.println("Trimmed string: " + trimmedString);
    }
}
