public class StringObject {
    public static void main(String[] args) {
        String name = new String("Ryle Kincaid");
        System.out.println(name);
    }
}
