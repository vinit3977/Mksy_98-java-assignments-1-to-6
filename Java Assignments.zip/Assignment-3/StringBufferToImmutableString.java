public class StringBufferToImmutableString {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer("Hello, World!");
        String immutableString = stringBuffer.toString();

        System.out.println("Immutable String (converted from StringBuffer): " + immutableString);
    }
}
